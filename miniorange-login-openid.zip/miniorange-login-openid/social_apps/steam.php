<?php


class mo_steam
{
    public $color="#021340";
}