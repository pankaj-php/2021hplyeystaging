<?php


class mo_foursquare
{
    public $color="#FE5478";
}