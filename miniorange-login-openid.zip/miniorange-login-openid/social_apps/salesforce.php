<?php


class mo_salesforce
{
    public $color="#009DDC";
}