<?php


class mo_github
{
    public $color="#000000";
}