<?php
class mo_wiebo
{
    public $color="#f74545";
}