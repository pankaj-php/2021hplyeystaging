<?php


class mo_dropbox
{
    public $color="#0D2481";
}