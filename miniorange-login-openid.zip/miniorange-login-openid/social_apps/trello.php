<?php


class mo_trello
{
    public $color="#0075B9";
}