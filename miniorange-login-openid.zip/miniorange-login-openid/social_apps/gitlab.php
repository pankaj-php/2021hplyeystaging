<?php


class mo_gitlab
{
    public $color="#DB4128";
}