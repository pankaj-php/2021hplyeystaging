<?php


class mo_apple
{
    public $color="#000000";
}