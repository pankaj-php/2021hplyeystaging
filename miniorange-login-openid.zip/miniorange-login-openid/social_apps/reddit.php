<?php


class mo_reddit
{
    public $color="#FF4401";
}