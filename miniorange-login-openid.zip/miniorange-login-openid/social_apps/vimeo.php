<?php


class mo_vimeo
{
    public $color="#1FB7EB";
}