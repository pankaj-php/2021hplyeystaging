<?php


class mo_stackexchange
{
    public $color="#163B7F";
}